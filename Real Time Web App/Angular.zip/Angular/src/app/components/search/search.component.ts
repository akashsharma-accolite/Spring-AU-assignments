import { BookService } from './../../providers/book.service';
import { Component, OnInit } from '@angular/core';
import { Book } from 'src/app/model/book';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})

export class SearchComponent implements OnInit {

  book: any ;
  books: any [];

  bookId: string;
  bookName: string;
  authorName: string;
  price: number;
  desc1: string;

  constructor(private bookService: BookService) { }

  ngOnInit() {
    this.bookService.getAllBooks().subscribe((response) => {
         if (response && response.length > 0) {
           this.books = response;
         }
       });
  }

  postData(book: any) {
    // const b = new Book(this.bookId, this.bookName, this.authorName, this.price, this.desc1);
    // this.bookService.putCheckoutInDb(b).subscribe((response) => {
    //   if (response) {
    //     console.log(response);
    //   }
    // });

    this.bookService.putCheckoutInDb(new Book(book.id, book.bookName, book.authorName, book.price, book.description))
          .subscribe((response) => {
            console.log(response);
          });
  }

}
