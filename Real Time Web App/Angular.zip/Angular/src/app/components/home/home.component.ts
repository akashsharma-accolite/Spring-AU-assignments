import { BookService } from './../../providers/book.service';
import { Component, OnInit } from '@angular/core';
import { Book } from './../../model/book';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  book: any ;
  books: any[];

  bookId: string;
  bookName: string;
  authorName: string;
  price: number;
  desc1: string;


  constructor(private bookService: BookService) { }

  ngOnInit() {
    // this.bookService.getAllBooks().subscribe((response) => {
    //   if (response && response.length > 0) {
    //     this.books = response;
    //   }
    // });

    // this.bookService.getBookById().subscribe((response) => {
    //   if (response) {
    //     this.book = response;
    //   }
    // });

  }

  postData() {
    const b = new Book(this.bookId, this.bookName, this.authorName, this.price, this.desc1);
    this.bookService.putInDb(b).subscribe((response) => {
      if (response) {
        console.log(response);
      }
    });
  }

}
