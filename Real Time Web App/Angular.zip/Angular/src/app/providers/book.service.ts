import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})

export class BookService {

  constructor(private http: HttpClient) {}

  getAllBooks(): Observable<any> {
    return this.http.get('/WebApp/books');
  }


  getBookById(): Observable<any> {
     return this.http.get('/WebApp/books/get/1');
   }


  putInDb(b): Observable<any> {
    return this.http.post('/WebApp/books', b);
  }

  putCheckoutInDb(b): Observable<any> {
    console.log(b);
    return this.http.post('/WebApp/booksCheckout', b);
  }

  getCheckedOutBooks(): Observable<any> {
    return this.http.get('/WebApp/booksCheckout');
  }



  }
