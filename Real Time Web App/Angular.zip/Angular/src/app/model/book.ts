export class Book {

id: any;
bookName: any;
authorName: any;
price: any;
description: any;

constructor(id , name, author, price , descr) {
  this.id = id;
  this.bookName = name;
  this.authorName = author;
  this.price = price;
  this.description = descr;
}

}
